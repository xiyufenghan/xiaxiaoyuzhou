---
name: xiaoyuzhou-wechat-layout
description: Use when formatting or typesetting articles for the WeChat public account 《浴缸里的小宇宙》, including 浴缸速记, 老A的判断, 世界正在变化, and 奇闻浴场. Produces clean WeChat-ready HTML using the account's established layout rules, column positioning, and brand assets.
---

# 《浴缸里的小宇宙》公众号排版

Use this skill when the user asks to format, 排版, publish, or generate HTML for articles from 《浴缸里的小宇宙》.

## Core Rule

WeChat already provides the cover image, title, author metadata, and excerpt. Do not repeat a large logo, big title, or cover-like hero inside the article body.

The body should prioritize reading comfort. Brand identity should be light and integrated into content modules.

## Column Routing

Choose one template:

- `浴缸速记`: daily lightweight template.
- `奇闻浴场`: daily lightweight template with 奇闻浴场 wording.
- `老A的判断`: structured long-form template.
- `世界正在变化`: weekly/monthly signals template.

If the user does not specify a column:

- Short thought, small observation, unfinished question -> `浴缸速记`.
- Story, urban legend, strange history, human behavior -> `奇闻浴场`.
- Fact + inference + correction + judgment -> `老A的判断`.
- Multiple trend signals, weekly/monthly recap -> `世界正在变化`.

## Templates

Bundled templates live in `templates/`:

- `01-日常轻量版-浴缸速记-奇闻浴场.html`
- `02-结构长文版-老A的判断.html`
- `03-周月报版-世界正在变化.html`

Bundled logo assets live in `assets/`:

- `bathtub-notes-transparent.png`
- `strange-bathhouse-transparent.png`
- `laoa-judgement-transparent.png`
- `world-changing-transparent.png`

When creating a final article HTML, copy the chosen template into the workspace output folder and edit it. Use relative asset paths when packaging, or absolute paths when previewing locally in the current workspace.

## Layout Rules

### Daily Lightweight

For `浴缸速记` and `奇闻浴场`:

- No large logo.
- No repeated article title.
- No full column description card at the top.
- Start with either a very small inline marker or directly with body text.
- Use at most one key judgment card unless the article genuinely needs more.
- Avoid large numbered sections.

### Structured Long Form

For `老A的判断`:

- No large logo.
- No repeated article title.
- Integrate the column name into the first gray intro card as a small eyebrow label.
- Use `01 / 02 / 03` sections when they clarify the reasoning.
- Use judgment cards for core claims.
- END block is allowed.

### Weekly / Monthly Signals

For `世界正在变化`:

- No large logo.
- No repeated article title.
- Integrate the column name into the first gray intro card as a small eyebrow label.
- Keep a compact table-of-contents module.
- Keep a "本期总判断" card.
- Each signal should answer: what happened, why it matters, who or what it affects.

## Editing Rules

Before formatting:

- Remove draft markers such as `升华新增部分`.
- Convert Markdown `**bold**` into HTML `<strong>`.
- Preserve the user's voice.
- Improve paragraph rhythm, but do not rewrite into generic公众号腔.
- Do not make every sentence a separate paragraph.
- Keep paragraph line-height around `2` and body font around `16px`.

## User Input Format

Recommended:

```text
栏目：
期数：
标题：
是否保留原文语气：是

正文：
...
```

If incomplete, infer reasonably from content.

## Output

Create one standalone HTML file in the current workspace, preferably under a relevant `wechat-layout/` or `outputs/.../wechat-layout/` folder.

Final response should include:

- The HTML file path.
- The selected template/column.
- Any notable edits, briefly.

